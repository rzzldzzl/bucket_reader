package com.splunk.journal.hadoop.examples;

import com.opencsv.CSVParser;
import com.splunk.journal.hadoop.RecordReaderHelper;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.Arrays;

/**
 * Reads in a raw-data journal file. For each event, it emits each of the following pairs:
 * "host" - host value from the event
 * "source" - source value from the event
 * "sourcetype" - sourcetype value from the event
 *
 * Created by kschon on 4/5/15.
 */
public class JournalMapper extends Mapper<Text, Text, Text, LongWritable> {
    Logger logger = Logger.getLogger(JournalMapper.class);

    CSVParser csvParser;
    String[] fieldNames;
    int hostIdx = -1;
    int sourceIdx = -1;
    int sourcetypeIdx = -1;

    Text fieldPair = new Text();
    final static LongWritable ONE = new LongWritable(1);

    public JournalMapper() {
    }

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        Configuration conf = context.getConfiguration();
        csvParser = new CSVParser(RecordReaderHelper.getSeparatorChar(conf), '"',
                RecordReaderHelper.getEscapeChar(conf));

        fieldNames = RecordReaderHelper.getValueFieldNames(conf);
        for (int i = 0; i < fieldNames.length; i++) {
            if (fieldNames[i].equals("host"))
                hostIdx = i;

            else if (fieldNames[i].equals("source"))
                sourceIdx = i;

            else if (fieldNames[i].equals("sourcetype"))
                sourcetypeIdx = i;
        }
        logger.info("Looking for host in column " + hostIdx);
        logger.info("Looking for source in column " + sourceIdx);
        logger.info("Looking for sourcetype in column " + sourcetypeIdx);
    }

    @Override
    protected void map(Text key, Text value, Context context) throws IOException, InterruptedException {
        byte[] valBytes = value.getBytes();
        String line = new String(valBytes, 0, value.getLength(), "utf-8");
        String[] fields = null;
        try {
            fields = csvParser.parseLine(line);
        }
        catch (IOException ex) {
            logger.error("Found unparsable line '" + line + "'", ex);
        }
        if (fields.length != fieldNames.length)
            logger.warn("Wrong number of fields received! Expected fields = " + Arrays.toString(fieldNames)
                    + ". Found values = " + Arrays.toString(fields));
        else {
            if (hostIdx > -1) {
                fieldPair.set("host = " + fields[hostIdx]);
                context.write(fieldPair, ONE);
            }
            if (sourceIdx > -1) {
                fieldPair.set("source = " + fields[sourceIdx]);
                context.write(fieldPair, ONE);
            }
            if (sourcetypeIdx > -1) {
                fieldPair.set("sourcetype = " + fields[sourcetypeIdx]);
                context.write(fieldPair, ONE);
            }
        }
    }
}
