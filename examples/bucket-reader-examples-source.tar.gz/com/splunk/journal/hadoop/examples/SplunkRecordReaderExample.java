package com.splunk.journal.hadoop.examples;

import com.splunk.journal.hadoop.mapreduce.JournalInputFormat;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.jobcontrol.ControlledJob;
import org.apache.hadoop.mapreduce.lib.jobcontrol.JobControl;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.Logger;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * A simple example to demonstrate use of <code>JournalInputFormat</code> and (implicitly)
 * <code>RawdataJournalReader</code>. To run, make sure that the Bucket Reader jar is in your classpath, in addition to
 * appropriate 3rd party jars.
 *
 * Created by kschon on 4/2/15.
 */
public class SplunkRecordReaderExample {
    static Logger logger = Logger.getLogger(SplunkRecordReaderExample.class);

    public Job createJob(String inputPath, String outputPath) throws IOException {
        Configuration configuration = new Configuration();

        // This demonstrates changing the value-format of the reader. Any format that includes these three fields would
        // work.
        configuration.set("com.splunk.journal.hadoop.value_format", "host,source,sourcetype");

        Job job = new Job(configuration, "Counting host, source, sourcetype");
        job.setJarByClass(SplunkRecordReaderExample.class);
        job.setInputFormatClass(JournalInputFormat.class);

        job.setMapperClass(JournalMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(LongWritable.class);

        job.setReducerClass(JournalReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(LongWritable.class);

        FileInputFormat.addInputPath(job, new Path(inputPath));
        FileOutputFormat.setOutputPath(job, new Path(outputPath));

        return job;
    }

    public static void main(String args[]) throws IOException, InterruptedException {
        String inputPath = args[0];
        String outputPath = args[1];

        FileUtil.fullyDelete(new File(outputPath));

        SplunkRecordReaderExample exampleApp = new SplunkRecordReaderExample();
        Job job = exampleApp.createJob(inputPath, outputPath);
        JobControl controller = new JobControl("Field counting");
        controller.addJob(new ControlledJob(job, new ArrayList<ControlledJob>()));
        controller.run();

        try {
            while (!controller.allFinished()) {
                logger.info("Waiting on search...");
                Thread.sleep(5000);
            }
        }
        finally {
            System.exit(0);
        }
    }
}
