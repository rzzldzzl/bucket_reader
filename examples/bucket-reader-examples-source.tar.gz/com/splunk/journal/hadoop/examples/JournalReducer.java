package com.splunk.journal.hadoop.examples;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Sums the values associated with each key.
 * Created by kschon on 4/5/15.
 */
class JournalReducer extends Reducer<Text, LongWritable, Text, LongWritable> {
    LongWritable count = new LongWritable();

    @Override
    protected void reduce(Text key, Iterable<LongWritable> values, Context context) throws IOException, InterruptedException {
        Map<String, Long> valueToCount = new HashMap<String, Long>();
        long sum = 0;
        for (LongWritable number : values) {
            sum += number.get();
        }
        count.set(sum);
        context.write(key, count);
    }

}
